package hotelaria;
import dataBase.conexaoBanco;
import modelo.Cliente;

public class TesteCliente {
    
    public static void main(String[] args){
        
    Cliente cliente = new Cliente(); 
    
        System.out.println("Insira o nome");
        cliente.getNome();
        System.out.println("Insira o CPF");
        cliente.getCpf();
        
    
    }
    
}
