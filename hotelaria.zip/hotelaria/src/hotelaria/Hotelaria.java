package hotelaria;
import dataBase.conexaoBanco;
import modelo.Cliente;
import java.sql.*;
import java.sql.PreparedStatement;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;
 /**
 * @author Thales Freitas
 * @version 1.0 
 * Sistema Hoetalria - Aquitetura de Software
 */
public class Hotelaria {
    private Connection connection;
    long IdCliente;
    long Cpf;
    String Nome ;
    String Endereco;
    String Telefone;
    String SituacaoCliente;
    String DataCadastro;
    String DataAtualizado;
    boolean EmDebito;
   
    public Hotelaria() throws SQLException{
        
    this.connection = new conexaoBanco().getConnection();
    
    }
    public void adiciona(Cliente cliente){
    String sql = "INSERT INTO cliente(Cpf,Nome,Endereco,Telefone,SituacaoCliente,DataCadastro,DataAtualizacao) VALUES(?,?,?,?,?,?,?)";
    try{ 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, cliente.getNome());
            stmt.setLong (2, cliente.getCpf());
            stmt.setString(3, cliente.getEndereco());
            stmt.setString(4, cliente.getTelefone());
            stmt.setString(5, cliente.getSituacaoCliente());
            stmt.setString(6, cliente.getDataCadastro());
            stmt.setString(7, cliente.getDataAtualizado());
            stmt.execute();
            stmt.close();
        }
    catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
    }
    
    
 }
